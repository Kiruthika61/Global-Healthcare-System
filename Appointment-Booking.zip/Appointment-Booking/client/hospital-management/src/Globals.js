module.exports = { 
    SERVER_URL : 'http://localhost:8080/v1/'
}